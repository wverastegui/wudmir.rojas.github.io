// script.js
document.addEventListener("DOMContentLoaded", () => {
  alert("Welcome to my portfolio!");
});
